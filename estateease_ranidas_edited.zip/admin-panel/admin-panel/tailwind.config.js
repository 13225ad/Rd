/** @type {import('tailwindcss').Config} */
module.exports = {
  darkMode: ["class"],
  content: [
    "./pages/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}",
    "./app/**/*.{ts,tsx}",
    "./src/**/*.{ts,tsx}",
  ],
  theme: {
    container: {
      center: true,
      padding: "2rem",
      screens: {
        "2xl": "1400px",
      },
    },
    extend: {
      backgroundColor: {
        "main-bg": "#edf2f6",
        // "main-dark-bg": "#161c24",
        "main-dark-bg": "#161c24",
        // "secondary-dark-bg": "#2b343b",
        "secondary-dark-bg": "#212b36",

        "light-gray": "#F7F7F7",
        "half-transparent": "#f2f6fc",
        "red-bg": "#e11d48",
      },
      colors: {
        "main-color": "#e11d48",
        "secondary-color": "#96a0af",
        "dark-gray": "#2b343b",
        "light-gray": "#1c1c1c",
        "dark-color": "#333e4b",
      },
      keyframes: {
        "accordion-down": {
          from: { height: 0 },
          to: { height: "var(--radix-accordion-content-height)" },
        },
        "accordion-up": {
          from: { height: "var(--radix-accordion-content-height)" },
          to: { height: 0 },
        },
      },
      animation: {
        "accordion-down": "accordion-down 0.2s ease-out",
        "accordion-up": "accordion-up 0.2s ease-out",
      },
    },
  },
  plugins: [require("tailwindcss-animate"), require("tailwind-scrollbar-hide")],
};
