export const MainColor = "#e11d48";
export const systemTheme = window.matchMedia(
  "(prefers-color-scheme: dark)"
).matches;
